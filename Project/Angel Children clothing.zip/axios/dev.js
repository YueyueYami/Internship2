module.exports = {
    pord: {
        baseUrl: 'https://api.it120.cc'
    },
    dev: {
        baseUrl: ''
    },
    loca: {
        baseUrl: ''
    }
}